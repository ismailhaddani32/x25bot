package com.x25bot.app

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.max

/** Adjustable table-selection frame + draggable floating scan toggle. */
class X25OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var frame: ScanFrame? = null
    private var bubble: TextView? = null
    private var scanning = false
    private var frameParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (frame != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val fp = WindowManager.LayoutParams(760, 430, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 220 }
        frameParams = fp
        frame = ScanFrame().also { wm.addView(it, fp) }
        val bp = WindowManager.LayoutParams(58, 58, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 320 }
        bubbleParams = bp
        bubble = TextView(this).apply {
            text = "SCAN"; textSize = 11f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(214,179,90)); setStroke(2, Color.WHITE) }
            setOnTouchListener(object : View.OnTouchListener {
                var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val p=bubbleParams ?: return false
                    when(e.action){
                        MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                        MotionEvent.ACTION_MOVE -> { if(kotlin.math.abs(e.rawX-sx)>8 || kotlin.math.abs(e.rawY-sy)>8) moved=true; p.x=(ox-(e.rawX-sx)).toInt(); p.y=(oy+(e.rawY-sy)).toInt(); wm.updateViewLayout(v,p); return true }
                        MotionEvent.ACTION_UP -> { if(!moved){ scanning=!scanning; text=if(scanning) "ON" else "SCAN"; frame?.invalidate();  }; return true }
                    }; return false
                }
            })
        }.also { wm.addView(it,bp) }
        return START_STICKY
    }

    inner class ScanFrame : View(this) {
        private val border=Paint( Paint.ANTI_ALIAS_FLAG ).apply { color=Color.rgb(214,179,90); style=Paint.Style.STROKE; strokeWidth=5f }
        private val shade=Paint().apply { color=0x2233CC99 }
        private val label=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; textSize=30f; setShadowLayer(4f,1f,1f,Color.BLACK) }
        private var downX=0f; private var downY=0f; private var startW=0; private var startH=0; private var startX=0; private var startY=0; private var resize=false
        override fun onDraw(c: Canvas) { super.onDraw(c); val r=RectF(3f,3f,width-3f,height-3f); c.drawRoundRect(r,12f,12f,shade); c.drawRoundRect(r,12f,12f,border); c.drawCircle(width-5f,height-5f,18f,border); c.drawText(if(scanning) "X25 POOL • TRACKING AREA" else "X25 POOL • MOVE / RESIZE",18f,38f,label); c.drawText("Drag frame to position • drag bottom-right to resize",18f,height-18f,label) }
        override fun onTouchEvent(e: MotionEvent): Boolean { val p=frameParams ?: return false; when(e.action){ MotionEvent.ACTION_DOWN->{ downX=e.rawX; downY=e.rawY; startW=p.width; startH=p.height; startX=p.x; startY=p.y; resize=e.x>width-65 && e.y>height-65; return true }; MotionEvent.ACTION_MOVE->{ val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt(); if(resize){p.width=max(260,startW+dx);p.height=max(180,startH+dy)} else {p.x=startX+dx;p.y=startY+dy}; wm.updateViewLayout(this,p); return true }; MotionEvent.ACTION_UP->{invalidate();return true} }; return true }
    }
    override fun onDestroy(){ try{frame?.let{wm.removeView(it)};bubble?.let{wm.removeView(it)}}catch(_:Exception){};frame=null;bubble=null;super.onDestroy() }
}
