package com.x25bot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val bg = Color.rgb(8, 11, 16)
    private val panel = Color.rgb(24, 31, 42)
    private val mint = Color.rgb(72, 221, 180)
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var configInfo: TextView
    private lateinit var connectButton: Button
    private var configFile: File? = null
    private var connected = false
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName() = "x25bot"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread {
                connected = newState == Tunnel.State.UP
                status.text = if (connected) "CONNECTED • WireGuard" else "DISCONNECTED"
                status.setTextColor(if (connected) mint else Color.LTGRAY)
                connectButton.text = if (connected) "DISCONNECT VPN" else "CONNECT VPN"
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) connectWireGuard()
            else toast("VPN permission was not granted")
        }

    private val configPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        val out = File(filesDir, "x25-profile.conf")
                        out.outputStream().use { input.copyTo(it) }
                        configFile = out
                    }
                    configInfo.text = "Profile loaded: ${configFile?.name}"
                    toast("WireGuard profile imported")
                } catch (e: Exception) {
                    toast("Could not import profile: ${e.message}")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(this)
        buildUi()
        val saved = File(filesDir, "x25-profile.conf")
        if (saved.exists()) {
            configFile = saved
            configInfo.text = "Profile loaded: ${saved.name}"
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(18))
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "X25 BOT"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val spacer = Space(this)
        val ready = TextView(this).apply {
            text = "● READY"
            textSize = 12f
            setTextColor(mint)
        }
        top.addView(title)
        top.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(ready)
        root.addView(top)

        val logo = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_compass)
            setColorFilter(mint)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, dp(100)))

        val subtitle = TextView(this).apply {
            text = "VPN CONTROL CENTER"
            textSize = 12f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }
        root.addView(subtitle)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(panel)
        }
        val heading = TextView(this).apply {
            text = "VPN CONNECTION"
            textSize = 13f
            setTextColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "DISCONNECTED"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(14), 0, dp(14))
        }
        connectButton = Button(this).apply {
            text = "CONNECT VPN"
            setTextColor(Color.BLACK)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(mint))
            setOnClickListener { if (connected) disconnectWireGuard() else requestConnect() }
        }
        configInfo = TextView(this).apply {
            text = "No WireGuard profile imported"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, 0)
        }
        card.addView(heading)
        card.addView(status)
        card.addView(connectButton, LinearLayout.LayoutParams(-1, dp(52)))
        card.addView(configInfo)
        val cardParams = LinearLayout.LayoutParams(-1, -2)
        cardParams.topMargin = dp(24)
        root.addView(card, cardParams)

        val import = makeButton("IMPORT FREE VPN PROFILE (.conf)") {
            configPicker.launch(arrayOf("text/*", "application/octet-stream"))
        }
        root.addView(import, marginParams())

        val ping = makeButton("PING TEST") { runPingTest() }
        root.addView(ping, marginParams())

        val five = makeButton("5-SECOND CONNECTION TEST") { runFiveSecondTest() }
        root.addView(five, marginParams())

        val overlay = makeButton("ENABLE FLOATING MENU") { enableOverlay() }
        root.addView(overlay, marginParams())

        val note = TextView(this).apply {
            text = "A VPN profile is required. X25 BOT does not include a free VPN server. Import a valid WireGuard .conf file from a provider you trust."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun requestConnect() {
        if (configFile == null || configFile?.exists() != true) {
            toast("Import a valid .conf profile first")
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) permissionLauncher.launch(intent) else connectWireGuard()
    }

    private fun connectWireGuard() {
        val file = configFile ?: return
        worker.execute {
            try {
                val config = file.inputStream().use { Config.parse(it) }
                backend?.setState(tunnel, Tunnel.State.UP, config)
            } catch (e: Exception) {
                runOnUiThread { toast("VPN connection failed: ${e.message}") }
            }
        }
    }

    private fun disconnectWireGuard() {
        worker.execute {
            try { backend?.setState(tunnel, Tunnel.State.DOWN, null) }
            catch (e: Exception) { runOnUiThread { toast("Disconnect failed: ${e.message}") } }
        }
    }

    private fun runPingTest() {
        status.text = "TESTING PING…"
        worker.execute {
            val start = System.currentTimeMillis()
            val result = try {
                Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 3500) }
                "${System.currentTimeMillis() - start} ms"
            } catch (_: Exception) { "Unavailable / timeout" }
            runOnUiThread { status.text = if (connected) "CONNECTED • Ping $result" else "Ping: $result" }
        }
    }

    private fun runFiveSecondTest() {
        status.text = "RUNNING SAFE TEST • 5s"
        val handler = android.os.Handler(mainLooper)
        val start = System.currentTimeMillis()
        val tick = object : Runnable {
            override fun run() {
                val remaining = 5 - ((System.currentTimeMillis() - start) / 1000).toInt()
                if (remaining > 0) {
                    status.text = "CONNECTION TEST • ${remaining}s"
                    handler.postDelayed(this, 1000)
                } else {
                    status.text = if (connected) "CONNECTED • TEST COMPLETE" else "DISCONNECTED • TEST COMPLETE"
                }
            }
        }
        handler.post(tick)
    }

    private fun enableOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName"))
            startActivity(i)
        } else {
            startService(Intent(this, X25OverlayService::class.java))
            toast("Floating X25 button enabled")
        }
    }

    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener { action() }
        }

    private fun marginParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
