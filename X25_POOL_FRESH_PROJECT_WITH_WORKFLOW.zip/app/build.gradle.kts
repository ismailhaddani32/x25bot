plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.x25pool.aim"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.x25pool.aim"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
