package com.x25pool.aim

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.hypot

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: AimView? = null
    private var controls: TextView? = null
    private var controlParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = AimView(this)
        overlay = view
        val full = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(view, full)

        val chip = TextView(this).apply {
            text = "X25 • تحريك العلامات"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(18, 28, 42))
            setPadding(18, 12, 18, 12)
            setOnClickListener { view.cycleSelection() }
            setOnLongClickListener {
                stopSelf()
                true
            }
        }
        controls = chip
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 70 }
        controlParams = p
        wm.addView(chip, p)
        chip.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(chip,p); return true }
                    MotionEvent.ACTION_UP -> { if (hypot((e.rawX-sx).toDouble(), (e.rawY-sy).toDouble()) < 12) view.cycleSelection(); return true }
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        overlay?.let { runCatching { wm.removeView(it) } }
        controls?.let { runCatching { wm.removeView(it) } }
        overlay = null; controls = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

private class AimView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val names = arrayOf("البيضاء", "الهدف", "الجيب")
    private val colors = intArrayOf(Color.CYAN, Color.YELLOW, Color.MAGENTA)
    private val points = arrayOf(PointF(0.30f,0.55f), PointF(0.58f,0.45f), PointF(0.82f,0.25f))
    private var selected = 0
    private var dragging = -1
    private var lastX = 0f
    private var lastY = 0f

    fun cycleSelection() { selected = (selected + 1) % 3; invalidate() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat(); val h=height.toFloat()
        // Path is a visual guide only; user places the three points manually.
        paint.style=Paint.Style.STROKE; paint.strokeWidth=4f; paint.color=Color.WHITE
        c.drawLine(points[0].x*w, points[0].y*h, points[1].x*w, points[1].y*h, paint)
        c.drawLine(points[1].x*w, points[1].y*h, points[2].x*w, points[2].y*h, paint)
        for (i in points.indices) {
            val x=points[i].x*w; val y=points[i].y*h
            paint.color=colors[i]; paint.style=Paint.Style.STROKE; paint.strokeWidth=5f
            c.drawCircle(x,y,28f,paint)
            paint.style=Paint.Style.FILL; paint.textSize=25f
            c.drawText(if (i==selected) "✦ ${names[i]}" else names[i], x+34f, y-22f, paint)
        }
        paint.color=Color.WHITE; paint.textSize=22f; paint.style=Paint.Style.FILL
        c.drawText("المحدد: ${names[selected]} • اضغط على العلامة واسحبها", 28f, h-48f, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w=width.toFloat(); val h=height.toFloat()
        when(e.action) {
            MotionEvent.ACTION_DOWN -> {
                dragging = points.indices.minByOrNull { i ->
                    hypot((points[i].x*w-e.x).toDouble(), (points[i].y*h-e.y).toDouble())
                } ?: -1
                if (dragging >= 0 && hypot((points[dragging].x*w-e.x).toDouble(), (points[dragging].y*h-e.y).toDouble()) < 85) {
                    selected=dragging; lastX=e.x; lastY=e.y; invalidate(); return true
                }
                dragging=-1
            }
            MotionEvent.ACTION_MOVE -> if (dragging>=0) {
                points[dragging].x=(e.x/w).coerceIn(0.02f,0.98f)
                points[dragging].y=(e.y/h).coerceIn(0.05f,0.95f)
                invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging=-1; return true }
        }
        return true
    }
}
