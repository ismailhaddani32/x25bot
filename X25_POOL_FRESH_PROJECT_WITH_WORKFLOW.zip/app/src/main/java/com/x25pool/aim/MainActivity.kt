package com.x25pool.aim

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(7, 11, 18))
        }
        val title = TextView(this).apply {
            text = "X25 POOL"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "MANUAL AIM ASSIST"
            textSize = 13f
            setTextColor(Color.rgb(0, 229, 255))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 32)
        }
        val start = Button(this).apply {
            text = "تشغيل"
            textSize = 18f
            setOnClickListener { startOverlay() }
        }
        val stop = Button(this).apply {
            text = "إيقاف"
            textSize = 18f
            setOnClickListener {
                stopService(Intent(this@MainActivity, AimOverlayService::class.java))
                Toast.makeText(this@MainActivity, "تم طلب إيقاف X25 POOL", Toast.LENGTH_SHORT).show()
            }
        }
        val instagram = TextView(this).apply {
            text = "Instagram Developer: @x25madara"
            textSize = 15f
            setTextColor(Color.rgb(255, 105, 180))
            gravity = Gravity.CENTER
            setPadding(0, 34, 0, 8)
            setOnClickListener {
                val uri = Uri.parse("https://www.instagram.com/x25madara/")
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        }
        val note = TextView(this).apply {
            text = "بعد التشغيل ستظهر علامات قابلة للتحريك فوق الشاشة. ضعها على الكرة البيضاء، الكرة الهدف، والجيب."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(start, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 12 })
        root.addView(stop, LinearLayout.LayoutParams(-1, 58))
        root.addView(instagram)
        root.addView(note)
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح للتطبيق بالظهور فوق التطبيقات الأخرى", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                requestOverlay
            )
            return
        }
        startService(Intent(this, AimOverlayService::class.java))
        Toast.makeText(this, "X25 POOL يعمل الآن", Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Android API but supported for this simple permission flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) startOverlay()
    }
}
