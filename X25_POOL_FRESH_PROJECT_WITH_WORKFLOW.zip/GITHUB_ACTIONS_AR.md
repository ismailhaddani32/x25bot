# طريقة بناء APK لمشروع X25 POOL

1. فك ضغط `X25_POOL_FRESH_PROJECT_WITH_WORKFLOW.zip`.
2. افتح مستودع GitHub الذي تريد استعماله.
3. ارفع جميع محتويات المجلد إلى جذر المستودع (لا ترفع ملف ZIP فقط).
   يجب أن يظهر `settings.gradle.kts` في جذر المستودع، وأن يظهر المسار
   `.github/workflows/build.yml`.
4. افتح تبويب Actions وشغّل `Build X25 POOL APK` إذا لم يبدأ تلقائياً.
5. بعد نجاح التشغيل، افتح نتيجة التشغيل ثم Artifacts وحمّل `X25-POOL-APK`.
6. فك ضغط ملف Artifact وثبّت `app-debug.apk` على هاتف Android.

هذا Workflow يبني نسخة Debug. لم يتم التحقق من تثبيت APK على هاتفك.
